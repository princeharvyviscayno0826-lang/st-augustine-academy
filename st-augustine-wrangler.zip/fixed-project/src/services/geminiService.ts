import { GoogleGenerativeAI, SchemaType } from "@google/generative-ai";
import { Student } from "../types";

const MODEL_NAME = 'gemini-1.5-flash';

const getApiKey = () => {
  return import.meta.env.VITE_GEMINI_API_KEY || '';
};

export const getStudentPerformanceInsights = async (student: Student) => {
  try {
    const genAI = new GoogleGenerativeAI(getApiKey());
    const model = genAI.getGenerativeModel({ 
      model: MODEL_NAME,
      generationConfig: {
        responseMimeType: "application/json",
        responseSchema: {
          type: SchemaType.OBJECT,
          properties: {
            summary: { type: SchemaType.STRING },
            strengths: { 
              type: SchemaType.ARRAY, 
              items: { type: SchemaType.STRING } 
            },
            weaknesses: { 
              type: SchemaType.ARRAY, 
              items: { type: SchemaType.STRING } 
            },
            recommendations: { 
              type: SchemaType.ARRAY, 
              items: { type: SchemaType.STRING } 
            }
          },
          required: ["summary", "strengths", "weaknesses", "recommendations"]
        }
      }
    });
    
    const prompt = `Evaluate the academic progress of ${student.name}. 
    Current Grades: ${JSON.stringify(student.grades)}.
    Task History: ${JSON.stringify(student.tasks)}.
    Progress: ${student.overallProgress}%.
    
    Provide a concise, professional analysis for the student's portal.`;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    return JSON.parse(text);
  } catch (error) {
    console.error('Error getting student insights:', error);
    return {
      summary: "Unable to generate insights at this time.",
      strengths: ["Data not available"],
      weaknesses: ["Data not available"],
      recommendations: ["Please try again later"]
    };
  }
};

export const getTeacherClassOverview = async (students: Student[]) => {
  try {
    const genAI = new GoogleGenerativeAI(getApiKey());
    const model = genAI.getGenerativeModel({ 
      model: MODEL_NAME,
      generationConfig: {
        responseMimeType: "application/json",
        responseSchema: {
          type: SchemaType.OBJECT,
          properties: {
            classHealth: { type: SchemaType.STRING },
            atRiskStudents: { 
              type: SchemaType.ARRAY, 
              items: { type: SchemaType.STRING } 
            },
            strategicAdvice: { type: SchemaType.STRING }
          },
          required: ["classHealth", "atRiskStudents", "strategicAdvice"]
        }
      }
    });
    
    const summaryData = students.map(s => ({ 
      name: s.name, 
      progress: s.overallProgress, 
      avgScore: s.grades.length > 0 ? 
        (s.grades.reduce((a, b) => a + b.score, 0) / s.grades.length).toFixed(1) : 
        0 
    }));
    
    const prompt = `Review the following class performance data: ${JSON.stringify(summaryData)}.
    Provide an administrative health check and identify students requiring intervention.`;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    return JSON.parse(text);
  } catch (error) {
    console.error('Error getting class overview:', error);
    return {
      classHealth: "Unable to assess at this time.",
      atRiskStudents: [],
      strategicAdvice: "Please try again later"
    };
  }
};
