
import React, { useState } from 'react';
import { User, Student, Assignment, Task } from './types';
import { MOCK_STUDENTS, MOCK_ASSIGNMENTS, MOCK_USERS } from './constants';
import { Login } from './components/Login';
import { StudentPortal } from './components/StudentPortal';
import { AdminDashboard } from './components/AdminDashboard';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [students, setStudents] = useState<Student[]>(MOCK_STUDENTS);
  const [assignments, setAssignments] = useState<Assignment[]>(MOCK_ASSIGNMENTS);
  const [users, setUsers] = useState<User[]>(MOCK_USERS);

  const handleLogin = (user: User) => setCurrentUser(user);
  const handleLogout = () => setCurrentUser(null);

  const handleAddTask = (studentId: string, taskData: Partial<Task>) => {
    setStudents(prev => prev.map(s => {
      if (s.id === studentId) {
        const newTask: Task = {
          id: `t-${Date.now()}`,
          title: taskData.title || 'Untitled Task',
          description: taskData.description || '',
          deadline: taskData.deadline || new Date().toISOString().split('T')[0],
          status: 'Pending',
          completionPercentage: 0
        };
        return { ...s, tasks: [newTask, ...s.tasks] };
      }
      return s;
    }));
  };

  const handleTaskUpload = (taskId: string, file: File) => {
    if (!currentUser) return;
    setStudents(prev => prev.map(s => {
      if (s.id === currentUser.id) {
        return {
          ...s,
          tasks: s.tasks.map(t => t.id === taskId ? { 
            ...t, 
            status: 'Proof Uploaded', 
            completionPercentage: 100, 
            proofFileName: file.name 
          } : t)
        };
      }
      return s;
    }));
  };

  const handleUpload = (title: string, file: File) => {
    if (!currentUser) return;
    const newAssignment: Assignment = {
      id: `a${Date.now()}`,
      studentId: currentUser.id,
      studentName: currentUser.name,
      title,
      fileName: file.name,
      fileData: 'base64_simulated',
      mimeType: file.type,
      status: 'pending',
      submittedAt: new Date().toISOString()
    };
    setAssignments([newAssignment, ...assignments]);
  };

  const handleGrade = (assignmentId: string, grade: string, feedback: string) => {
    setAssignments(prev => prev.map(ass => ass.id === assignmentId ? { ...ass, status: 'graded', grade, feedback } : ass));
  };

  const handleResetPassword = (userId: string, newPw: string) => {
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, password: newPw } : u));
  };

  if (!currentUser) return (
    <Login 
      onLogin={handleLogin} 
      users={users} 
    />
  );

  const activeStudentData = students.find(s => s.id === currentUser.id) || students[0];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-indigo-100 selection:text-indigo-900">
      <nav className="bg-white border-b border-slate-100 h-20 px-4 md:px-8 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-black shrink-0 shadow-lg shadow-indigo-200">S</div>
          <span className="text-base md:text-xl font-black text-slate-900 tracking-tight leading-none uppercase">
            ST AUGUSTINE ACADEMY <br className="hidden md:block" />
            <span className="text-indigo-600 text-xs md:text-sm">OF PAMPANGA, INC.</span>
          </span>
        </div>
        <div className="flex items-center gap-3 md:gap-6">
          <div className="hidden sm:flex flex-col items-end">
            <span className="text-sm font-bold text-slate-900">{currentUser.name}</span>
            <span className="text-[10px] font-black uppercase tracking-widest text-indigo-500 bg-indigo-50 px-2 py-0.5 rounded-full">{currentUser.role} Portal</span>
          </div>
          <button onClick={handleLogout} className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-400 hover:text-rose-500 hover:bg-rose-50 transition-all group">
            <svg className="w-5 h-5 group-hover:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
            </svg>
          </button>
        </div>
      </nav>
      
      <div className="flex-1">
        {currentUser.role === 'student' ? (
          <StudentPortal 
            student={activeStudentData} 
            assignments={assignments} 
            onUpload={handleUpload} 
            onTaskUpload={handleTaskUpload}
          />
        ) : (
          <AdminDashboard 
            students={students} 
            assignments={assignments} 
            users={users} 
            onGrade={handleGrade} 
            onResetPassword={handleResetPassword}
            onAddTask={handleAddTask}
          />
        )}
      </div>

      <footer className="bg-white border-t border-slate-100 py-8 px-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-slate-400 text-[10px] font-black uppercase tracking-widest">
        <span>© 2024 ST AUGUSTINE ACADEMY OF PAMPANGA, INC. - ALL RIGHTS RESERVED</span>
        <div className="flex gap-6">
          <a href="#" className="hover:text-indigo-600 transition-colors">Faculty Directory</a>
          <a href="#" className="hover:text-indigo-600 transition-colors">Privacy</a>
          <a href="#" className="hover:text-indigo-600 transition-colors">Support</a>
        </div>
      </footer>
    </div>
  );
};

export default App;
