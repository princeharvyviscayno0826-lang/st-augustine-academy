
import { Student, Assignment, User, Task } from './types';

export const MOCK_USERS: User[] = [
  { 
    id: 's1', 
    email: 'student@school.edu', 
    password: 'password123', 
    role: 'student', 
    name: 'Jamie Muyrong', 
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aria' 
  },
  { 
    id: 't1', 
    email: 'teacher@school.edu', 
    password: 'password123', 
    role: 'teacher', 
    name: 'Paul Salazar', 
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Paul' 
  },
  { 
    id: 'a1', 
    email: 'admin@school.edu', 
    password: 'password123', 
    role: 'admin', 
    name: 'Mark Capulong', 
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mark' 
  }
];

const INITIAL_TASKS: Task[] = [
  { id: 't-1', title: 'Calculus Assignment 1', description: 'Solve chapters 1-3 from the textbook.', deadline: '2024-04-15', status: 'Pending', completionPercentage: 0 },
  { id: 't-2', title: 'History Essay', description: 'Write 1000 words on the Industrial Revolution.', deadline: '2024-04-20', status: 'Proof Uploaded', completionPercentage: 100, proofFileName: 'essay_final.pdf' },
  { id: 't-3', title: 'Physics Lab Report', description: 'Complete the optics experiment report.', deadline: '2024-04-25', status: 'Verified', completionPercentage: 100, proofFileName: 'lab_report_v2.docx' }
];

export const MOCK_STUDENTS: Student[] = [
  {
    id: 's1',
    name: 'Jamie Muyrong',
    email: 'student@school.edu',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aria',
    overallProgress: 78,
    tasks: [...INITIAL_TASKS],
    grades: [
      { subject: 'Mathematics', score: 85, total: 100, date: '2024-03-01' },
      { subject: 'Physics', score: 72, total: 100, date: '2024-03-05' },
      { subject: 'English', score: 90, total: 100, date: '2024-03-10' },
      { subject: 'History', score: 65, total: 100, date: '2024-03-12' },
    ]
  },
  {
    id: 's2',
    name: 'Sarah Miller',
    email: 'sarah.m@school.edu',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
    overallProgress: 92,
    tasks: [
      { id: 't-4', title: 'Chemistry Lab', description: 'Report on titration.', deadline: '2024-04-18', status: 'Pending', completionPercentage: 0 }
    ],
    grades: [
      { subject: 'Mathematics', score: 95, total: 100, date: '2024-03-01' },
      { subject: 'Physics', score: 88, total: 100, date: '2024-03-05' },
      { subject: 'English', score: 94, total: 100, date: '2024-03-10' },
    ]
  }
];

export const MOCK_ASSIGNMENTS: Assignment[] = [
  {
    id: 'a1',
    studentId: 's1',
    studentName: 'Jamie Muyrong',
    title: 'Kinematics Lab Report',
    fileName: 'lab_report.pdf',
    fileData: 'base64_placeholder',
    mimeType: 'application/pdf',
    status: 'pending',
    submittedAt: '2024-03-14T10:30:00Z'
  }
];
