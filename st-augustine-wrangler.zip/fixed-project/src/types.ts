
export interface Grade {
  subject: string;
  score: number;
  total: number;
  date: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  deadline: string;
  status: 'Pending' | 'Proof Uploaded' | 'Verified';
  completionPercentage: number;
  proofFileName?: string;
}

export interface Assignment {
  id: string;
  studentId: string;
  studentName: string;
  title: string;
  fileName: string;
  fileData: string; // Base64
  mimeType: string;
  status: 'pending' | 'graded';
  grade?: string;
  feedback?: string;
  submittedAt: string;
}

export interface Student {
  id: string;
  name: string;
  email: string;
  avatar: string;
  grades: Grade[];
  tasks: Task[];
  overallProgress: number;
}

export type Role = 'student' | 'teacher' | 'admin';

export interface User {
  id: string;
  email: string;
  password: string;
  role: Role;
  name: string;
  avatar?: string;
}

export interface AppState {
  currentUser: User | null;
  students: Student[];
  assignments: Assignment[];
}
