
import React, { useState } from 'react';
import { Student, Assignment } from '../types';
import { AISight } from './AISight';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface StudentDashboardProps {
  student: Student;
  assignments: Assignment[];
  onUpload: (title: string, file: File) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ student, assignments, onUpload }) => {
  const [uploadTitle, setUploadTitle] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (uploadTitle && selectedFile) {
      onUpload(uploadTitle, selectedFile);
      setUploadTitle('');
      setSelectedFile(null);
    }
  };

  const myAssignments = assignments.filter(a => a.studentId === student.id);

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8 space-y-8">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-center gap-6 bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
        <img src={student.avatar} alt={student.name} className="w-24 h-24 rounded-full border-4 border-indigo-50 shadow-md" />
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-slate-900">Welcome back, {student.name}!</h1>
          <p className="text-slate-500">Student ID: {student.id} | Academic Year: 2023-2024</p>
          <div className="mt-4 flex items-center gap-4">
            <div className="flex-1 h-3 bg-slate-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-indigo-600 rounded-full transition-all duration-1000"
                style={{ width: `${student.overallProgress}%` }}
              ></div>
            </div>
            <span className="font-bold text-indigo-600">{student.overallProgress}% Progress</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Col: Grades & Charts */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <h2 className="text-xl font-bold mb-6 flex items-center gap-2 text-slate-800">
              <svg className="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
              Academic Performance Trends
            </h2>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={student.grades}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="subject" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Line type="monotone" dataKey="score" stroke="#4f46e5" strokeWidth={3} dot={{ r: 6, fill: '#4f46e5' }} activeDot={{ r: 8 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <AISight student={student} />

          {/* Grades Table */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-800">Subject Breakdown</h2>
              <span className="text-sm text-slate-500">{student.grades.length} Subjects Evaluated</span>
            </div>
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-slate-500 uppercase text-xs font-semibold">
                <tr>
                  <th className="px-6 py-4">Subject</th>
                  <th className="px-6 py-4">Score</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4 text-right">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {student.grades.map((grade, idx) => (
                  <tr key={idx} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 font-medium text-slate-900">{grade.subject}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full ${grade.score >= 80 ? 'bg-green-500' : grade.score >= 60 ? 'bg-amber-500' : 'bg-red-500'}`}></span>
                        {grade.score} / {grade.total}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm">
                       {grade.score >= 50 ? (
                         <span className="text-green-700 bg-green-50 px-2 py-1 rounded">Passed</span>
                       ) : (
                         <span className="text-red-700 bg-red-50 px-2 py-1 rounded">Action Required</span>
                       )}
                    </td>
                    <td className="px-6 py-4 text-right text-slate-500 text-sm">{grade.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Col: Assignments & Uploads */}
        <div className="space-y-8">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2 text-slate-800">
              <svg className="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
              </svg>
              Submit Assignment
            </h2>
            <form onSubmit={handleUploadSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Assignment Title</label>
                <input 
                  type="text"
                  required
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
                  placeholder="e.g., History Essay"
                />
              </div>
              <div className="relative border-2 border-dashed border-slate-200 rounded-xl p-8 text-center hover:border-indigo-300 transition-colors group">
                <input 
                  type="file" 
                  onChange={handleFileChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                  required
                />
                <div className="space-y-2">
                  <p className="text-slate-600 text-sm font-medium">
                    {selectedFile ? selectedFile.name : 'Click to select or drag and drop'}
                  </p>
                  <p className="text-slate-400 text-xs">PDF, DOCX, or PNG up to 10MB</p>
                </div>
              </div>
              <button 
                type="submit"
                className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200 active:scale-[0.98]"
              >
                Upload & Submit
              </button>
            </form>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <h2 className="text-xl font-bold mb-4 text-slate-800">My Submissions</h2>
            <div className="space-y-4">
              {myAssignments.length === 0 && <p className="text-slate-500 text-sm text-center py-4">No assignments submitted yet.</p>}
              {myAssignments.map((ass) => (
                <div key={ass.id} className="p-4 rounded-xl bg-slate-50 border border-slate-100 flex items-start gap-3">
                  <div className="bg-indigo-100 p-2 rounded-lg text-indigo-600">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-slate-900 truncate">{ass.title}</p>
                    <p className="text-xs text-slate-500">{new Date(ass.submittedAt).toLocaleDateString()}</p>
                    {ass.status === 'graded' ? (
                      <div className="mt-2 flex items-center justify-between">
                        <span className="text-xs font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded">Graded: {ass.grade}</span>
                      </div>
                    ) : (
                      <span className="mt-2 inline-block text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">Pending Review</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
