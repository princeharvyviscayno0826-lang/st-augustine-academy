
import React, { useState } from 'react';
import { User } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
  users: User[];
}

export const Login: React.FC<LoginProps> = ({ onLogin, users }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [resetMessage, setResetMessage] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = users.find(
      u => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );
    if (user) {
      onLogin(user);
    } else {
      setError('Invalid email or password. Hint: default passwords are "password123".');
    }
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    const user = users.find(u => u.email.toLowerCase() === forgotEmail.toLowerCase());
    if (user) {
      setResetMessage(`Password hint: Your current password is "${user.password}". In a real app, a recovery link would be sent.`);
    } else {
      setResetMessage('Email not found. Please use a valid mock email.');
    }
  };

  if (isForgotPassword) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-3xl p-10 shadow-xl border border-slate-100 animate-in fade-in zoom-in duration-300">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-black text-slate-900 leading-tight">Reset Password</h1>
            <p className="text-slate-500 mt-2 uppercase text-[10px] font-black tracking-widest">ST AUGUSTINE ACADEMY</p>
          </div>

          <form onSubmit={handleForgotPassword} className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">School Email</label>
              <input 
                type="email"
                required
                value={forgotEmail}
                onChange={(e) => setForgotEmail(e.target.value)}
                placeholder="name@school.edu"
                className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all"
              />
            </div>

            {resetMessage && (
              <div className="p-4 bg-indigo-50 rounded-2xl border border-indigo-100">
                <p className="text-indigo-700 text-sm font-medium">{resetMessage}</p>
              </div>
            )}

            <button 
              type="submit"
              className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
            >
              Send Recovery Link
            </button>
            
            <button 
              type="button"
              onClick={() => {
                setIsForgotPassword(false);
                setResetMessage('');
              }}
              className="w-full text-center text-sm font-bold text-indigo-600 hover:text-indigo-700"
            >
              Back to Login
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-3xl p-10 shadow-xl border border-slate-100 animate-in fade-in zoom-in duration-300">
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-indigo-600 rounded-2xl mx-auto flex items-center justify-center text-white text-3xl font-black mb-6 shadow-lg shadow-indigo-500/10">S</div>
          <h1 className="text-2xl font-black text-slate-900 leading-tight uppercase">ST AUGUSTINE ACADEMY <br /><span className="text-indigo-600 text-lg">OF PAMPANGA, INC.</span></h1>
          <p className="text-slate-500 mt-2 text-xs font-bold uppercase tracking-widest">Academic Management Portal</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">School Email</label>
            <input 
              type="email"
              required
              value={email}
              onChange={(e) => { setEmail(e.target.value); setError(''); }}
              placeholder="name@school.edu"
              className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all"
            />
          </div>

          <div>
            <div className="flex justify-between mb-2">
              <label className="text-sm font-bold text-slate-700">Password</label>
              <button 
                type="button"
                onClick={() => setIsForgotPassword(true)}
                className="text-sm font-bold text-indigo-600 hover:text-indigo-700"
              >
                Forgot Password?
              </button>
            </div>
            <input 
              type="password"
              required
              value={password}
              onChange={(e) => { setPassword(e.target.value); setError(''); }}
              placeholder="••••••••"
              className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all"
            />
          </div>

          {error && <p className="text-red-500 text-sm font-medium">{error}</p>}

          <button 
            type="submit"
            className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 active:scale-[0.98]"
          >
            Sign In to Portal
          </button>
        </form>

        <div className="mt-10 pt-8 border-t border-slate-100">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 text-center">Quick Select Account</p>
          <div className="grid grid-cols-1 gap-2">
            {[
              { label: 'Student', email: 'student@school.edu' },
              { label: 'Teacher', email: 'teacher@school.edu' },
              { label: 'Admin', email: 'admin@school.edu' },
            ].map(item => (
              <button 
                key={item.email}
                onClick={() => {
                  setEmail(item.email);
                  setPassword('password123');
                }}
                className="flex justify-between items-center px-4 py-2 bg-slate-50 hover:bg-indigo-50 rounded-xl border border-slate-100 transition-colors text-left"
              >
                <span className="text-xs font-bold text-slate-700">{item.label}</span>
                <span className="text-xs text-indigo-600 font-medium">{item.email}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
