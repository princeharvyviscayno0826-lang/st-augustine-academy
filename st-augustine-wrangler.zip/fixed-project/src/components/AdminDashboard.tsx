
import React, { useState } from 'react';
import { Student, Assignment, User, Task } from '../types';
import { getTeacherClassOverview } from '../services/geminiService';

interface AdminDashboardProps {
  students: Student[];
  assignments: Assignment[];
  users: User[];
  onGrade: (assignmentId: string, grade: string, feedback: string) => void;
  onResetPassword: (userId: string, newPw: string) => void;
  onAddTask: (studentId: string, task: Partial<Task>) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ students, assignments, users, onGrade, onResetPassword, onAddTask }) => {
  const [activeTab, setActiveTab] = useState<'roster' | 'submissions' | 'users'>('roster');
  const [aiReport, setAiReport] = useState<any>(null);
  const [loadingAI, setLoadingAI] = useState(false);
  const [gradingModal, setGradingModal] = useState<{ id: string, title: string } | null>(null);
  const [gradeInput, setGradeInput] = useState('');
  const [feedbackInput, setFeedbackInput] = useState('');
  const [showPasswords, setShowPasswords] = useState(false);
  
  const [resetModal, setResetModal] = useState<User | null>(null);
  const [newPassword, setNewPassword] = useState('');

  // Task Creation Modal State
  const [taskModal, setTaskModal] = useState<Student | null>(null);
  const [newTask, setNewTask] = useState({ title: '', description: '', deadline: '' });

  const pendingAssignments = assignments.filter(a => a.status === 'pending');

  const handleGenerateClassReport = async () => {
    setLoadingAI(true);
    try {
      const result = await getTeacherClassOverview(students);
      setAiReport(result);
    } catch (error) {
      console.error(error);
    } finally {
      setLoadingAI(false);
    }
  };

  const submitGrade = () => {
    if (gradingModal && gradeInput) {
      onGrade(gradingModal.id, gradeInput, feedbackInput);
      setGradingModal(null);
      setGradeInput('');
      setFeedbackInput('');
    }
  };

  const handlePasswordResetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (resetModal && newPassword) {
      onResetPassword(resetModal.id, newPassword);
      setResetModal(null);
      setNewPassword('');
    }
  };

  const handleAddTaskSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (taskModal && newTask.title) {
      onAddTask(taskModal.id, newTask);
      setTaskModal(null);
      setNewTask({ title: '', description: '', deadline: '' });
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-8 space-y-8">
      <div className="bg-white text-slate-900 p-8 rounded-2xl shadow-sm border border-slate-200 flex flex-col md:flex-row justify-between items-center gap-6">
        <div>
          <h1 className="text-3xl font-black">Administration Hub</h1>
          <p className="text-slate-500 mt-1 font-medium">Institution Control & Academic Management</p>
        </div>
        <div className="flex gap-4">
          <div className="bg-slate-50 px-6 py-3 rounded-xl border border-slate-100 text-center">
            <p className="text-slate-400 text-[10px] uppercase font-black tracking-widest">Total Accounts</p>
            <p className="text-2xl font-black text-slate-900">{users.length}</p>
          </div>
          <div className="bg-slate-50 px-6 py-3 rounded-xl border border-slate-100 text-center">
            <p className="text-slate-400 text-[10px] uppercase font-black tracking-widest">Files Pending</p>
            <p className="text-2xl font-black text-indigo-600">{pendingAssignments.length}</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="flex border-b border-slate-100 bg-slate-50/50">
          <button onClick={() => setActiveTab('roster')} className={`px-8 py-4 font-bold transition-all ${activeTab === 'roster' ? 'text-indigo-600 bg-white border-t-2 border-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}>Class Roster</button>
          <button onClick={() => setActiveTab('submissions')} className={`px-8 py-4 font-bold transition-all ${activeTab === 'submissions' ? 'text-indigo-600 bg-white border-t-2 border-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}>Submissions ({pendingAssignments.length})</button>
          <button onClick={() => setActiveTab('users')} className={`px-8 py-4 font-bold transition-all ${activeTab === 'users' ? 'text-indigo-600 bg-white border-t-2 border-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}>User Security</button>
        </div>

        <div className="p-6">
          {activeTab === 'roster' && (
            <div className="space-y-8 animate-in fade-in duration-300">
              <div className="bg-indigo-50 border border-indigo-100 rounded-2xl p-6 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold flex items-center gap-2 text-indigo-900"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg> AI Class Insights</h2>
                  <button onClick={handleGenerateClassReport} disabled={loadingAI} className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg font-bold transition-all disabled:opacity-50">{loadingAI ? 'Analyzing...' : 'Refresh Insights'}</button>
                </div>
                {aiReport && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                    <div className="bg-white p-4 rounded-xl border border-indigo-100">
                      <h3 className="font-bold text-indigo-700 mb-2">Health</h3>
                      <p className="text-sm text-slate-700">{aiReport.classHealth}</p>
                    </div>
                    <div className="bg-white p-4 rounded-xl border border-indigo-100">
                      <h3 className="font-bold text-rose-700 mb-2">At Risk</h3>
                      <ul className="list-disc list-inside text-sm text-slate-700">{aiReport.atRiskStudents.map((s: string, i: number) => <li key={i}>{s}</li>)}</ul>
                    </div>
                  </div>
                )}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {students.map(student => (
                  <div key={student.id} className="p-6 rounded-3xl border border-slate-100 bg-white shadow-sm hover:shadow-md transition-all group">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-4">
                        <img src={student.avatar} className="w-12 h-12 rounded-full border border-slate-100" />
                        <div><h4 className="font-bold text-slate-900">{student.name}</h4><p className="text-[10px] uppercase font-black text-slate-400">{student.id}</p></div>
                      </div>
                      <button 
                        onClick={() => setTaskModal(student)}
                        className="opacity-0 group-hover:opacity-100 px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-indigo-600 hover:text-white transition-all"
                      >
                        Assign Task
                      </button>
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center text-xs font-bold text-slate-500">
                        <span>Course Progress</span>
                        <span>{student.overallProgress}%</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full bg-indigo-500" style={{width: `${student.overallProgress}%`}}></div>
                      </div>
                    </div>
                    <div className="mt-4 pt-4 border-t border-slate-50 flex items-center justify-between">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{student.tasks.length} active tasks</p>
                      <div className="flex -space-x-1.5">
                        {student.tasks.slice(0, 3).map(t => (
                           <div key={t.id} title={t.title} className={`w-4 h-4 rounded-full border border-white ${t.status === 'Verified' ? 'bg-emerald-500' : t.status === 'Proof Uploaded' ? 'bg-indigo-500' : 'bg-slate-300'}`}></div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'submissions' && (
            <div className="space-y-4 animate-in fade-in duration-300">
              {assignments.length === 0 && <div className="text-center py-12 text-slate-400 font-bold uppercase text-xs tracking-widest">No pending submissions</div>}
              {assignments.map(ass => (
                <div key={ass.id} className="flex flex-col md:flex-row items-center justify-between p-6 bg-white rounded-2xl border border-slate-100 gap-4 shadow-sm">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-center text-slate-400"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg></div>
                    <div><h4 className="font-bold text-slate-900">{ass.title}</h4><p className="text-xs text-slate-500">From {ass.studentName}</p></div>
                  </div>
                  <div className="flex gap-2">
                    <button className="px-4 py-2 text-xs font-bold bg-slate-50 border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors">Preview</button>
                    {ass.status === 'pending' ? (
                      <button onClick={() => setGradingModal({id: ass.id, title: ass.title})} className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100">Grade</button>
                    ) : (
                      <span className="px-4 py-2 text-xs font-bold text-green-700 bg-green-50 rounded-lg">Score: {ass.grade}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'users' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-black">Registered Accounts</h3>
                <button 
                  onClick={() => setShowPasswords(!showPasswords)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${showPasswords ? 'bg-rose-500 text-white' : 'bg-slate-900 text-white'}`}
                >
                  {showPasswords ? 'Hide Passwords' : 'Reveal Passwords'}
                </button>
              </div>
              <div className="grid grid-cols-1 gap-4">
                {users.map(user => (
                  <div key={user.id} className="flex flex-col md:flex-row items-center justify-between p-6 bg-white border border-slate-100 rounded-3xl shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-center gap-6">
                      <img src={user.avatar} className="w-16 h-16 rounded-2xl border-4 border-slate-50 shadow-sm" />
                      <div>
                        <h4 className="font-black text-lg text-slate-900">{user.name}</h4>
                        <p className="text-slate-400 font-bold text-sm">{user.email}</p>
                        <span className="text-[10px] font-black uppercase bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded mt-1 inline-block">{user.role}</span>
                      </div>
                    </div>
                    <div className="flex flex-col md:flex-row items-center gap-4 mt-4 md:mt-0">
                      <div className="px-8 py-4 bg-slate-50 rounded-2xl border border-slate-100 w-full md:w-auto text-center md:text-left">
                        <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Security Credential</p>
                        <p className={`font-mono text-lg font-bold ${showPasswords ? 'text-indigo-600' : 'text-slate-300 blur-[3px]'}`}>
                          {showPasswords ? user.password : '••••••••••••'}
                        </p>
                      </div>
                      <button 
                        onClick={() => setResetModal(user)}
                        className="px-6 py-4 bg-indigo-50 text-indigo-600 rounded-2xl font-bold text-xs uppercase tracking-widest hover:bg-indigo-100 transition-colors"
                      >
                        Reset
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {gradingModal && (
        <div className="fixed inset-0 bg-white/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl border border-slate-100">
            <h2 className="text-2xl font-black mb-6">Grade Submission</h2>
            <div className="space-y-4">
              <input value={gradeInput} onChange={e => setGradeInput(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl outline-none" placeholder="Grade (e.g. A, 90%)" />
              <textarea value={feedbackInput} onChange={e => setFeedbackInput(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl h-24 outline-none" placeholder="Feedback" />
              <div className="flex gap-2">
                <button onClick={() => setGradingModal(null)} className="flex-1 py-3 font-bold text-slate-400">Cancel</button>
                <button onClick={submitGrade} className="flex-1 py-3 bg-indigo-600 text-white font-bold rounded-xl shadow-lg shadow-indigo-100">Save</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {resetModal && (
        <div className="fixed inset-0 bg-white/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-200">
            <div className="mb-6">
              <h2 className="text-2xl font-black">Reset Password</h2>
              <p className="text-sm text-slate-500 font-medium">Changing credentials for <span className="text-indigo-600 font-bold">{resetModal.name}</span></p>
            </div>
            <form onSubmit={handlePasswordResetSubmit} className="space-y-4">
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 block">New Password</label>
                <input 
                  type="text" 
                  autoFocus
                  required
                  value={newPassword} 
                  onChange={e => setNewPassword(e.target.value)} 
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all font-mono font-bold" 
                  placeholder="Enter new password..." 
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button 
                  type="button"
                  onClick={() => { setResetModal(null); setNewPassword(''); }} 
                  className="flex-1 py-4 font-bold text-slate-400 hover:text-slate-600 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="flex-1 py-4 bg-slate-900 text-white font-bold rounded-2xl shadow-xl shadow-slate-200 hover:bg-black transition-all active:scale-[0.98]"
                >
                  Confirm Reset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Task Creation Modal */}
      {taskModal && (
        <div className="fixed inset-0 bg-white/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-200">
            <div className="mb-6">
              <h2 className="text-2xl font-black">Assign Task</h2>
              <p className="text-sm text-slate-500 font-medium">Assigning to <span className="text-indigo-600 font-bold">{taskModal.name}</span></p>
            </div>
            <form onSubmit={handleAddTaskSubmit} className="space-y-4">
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 block">Task Title</label>
                <input 
                  required
                  value={newTask.title} 
                  onChange={e => setNewTask({...newTask, title: e.target.value})} 
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all font-bold" 
                  placeholder="e.g., Mathematics Prep" 
                />
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 block">Description</label>
                <textarea 
                  value={newTask.description} 
                  onChange={e => setNewTask({...newTask, description: e.target.value})} 
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none h-24 transition-all font-bold" 
                  placeholder="Enter task details..." 
                />
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 block">Deadline</label>
                <input 
                  type="date"
                  required
                  value={newTask.deadline} 
                  onChange={e => setNewTask({...newTask, deadline: e.target.value})} 
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all font-bold" 
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button 
                  type="button"
                  onClick={() => setTaskModal(null)} 
                  className="flex-1 py-4 font-bold text-slate-400 hover:text-slate-600 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="flex-1 py-4 bg-indigo-600 text-white font-bold rounded-2xl shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-[0.98]"
                >
                  Assign Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
