
import React, { useState } from 'react';
import { Student } from '../types';
import { getStudentPerformanceInsights } from '../services/geminiService';

interface AISightProps {
  student: Student;
}

export const AISight: React.FC<AISightProps> = ({ student }) => {
  const [loading, setLoading] = useState(false);
  const [insight, setInsight] = useState<any>(null);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const result = await getStudentPerformanceInsights(student);
      setInsight(result);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-indigo-50 border border-indigo-100 rounded-3xl p-6 shadow-sm">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <h3 className="text-lg font-black text-indigo-900 flex items-center gap-2">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
          Gemini AI Performance Insight
        </h3>
        <button 
          onClick={handleGenerate}
          disabled={loading}
          className="bg-indigo-600 text-white px-6 py-2 rounded-xl text-sm font-bold hover:bg-indigo-700 disabled:opacity-50 transition-colors shadow-lg shadow-indigo-200"
        >
          {loading ? 'Analyzing Student Data...' : 'Generate New Insight'}
        </button>
      </div>

      {!insight && !loading && (
        <p className="text-indigo-700 text-sm font-medium">Connect with Gemini AI to receive high-level pedagogical analysis and personalized recovery steps based on your current academic record.</p>
      )}

      {loading && (
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-indigo-200 rounded-full w-3/4"></div>
          <div className="h-4 bg-indigo-200 rounded-full w-1/2"></div>
          <div className="grid grid-cols-2 gap-4">
            <div className="h-24 bg-indigo-100 rounded-2xl"></div>
            <div className="h-24 bg-indigo-100 rounded-2xl"></div>
          </div>
        </div>
      )}

      {insight && (
        <div className="space-y-6 animate-in fade-in zoom-in-95 duration-500">
          <p className="text-slate-700 italic font-medium text-lg leading-relaxed">"{insight.summary}"</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-5 rounded-2xl border border-indigo-100">
              <h4 className="font-black text-emerald-600 text-xs uppercase tracking-widest mb-3">Core Strengths</h4>
              <ul className="text-sm text-slate-600 list-disc list-inside space-y-2">
                {insight.strengths.map((s: string, i: number) => <li key={i} className="leading-tight">{s}</li>)}
              </ul>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-indigo-100">
              <h4 className="font-black text-rose-600 text-xs uppercase tracking-widest mb-3">Critical Targets</h4>
              <ul className="text-sm text-slate-600 list-disc list-inside space-y-2">
                {insight.weaknesses.map((w: string, i: number) => <li key={i} className="leading-tight">{w}</li>)}
              </ul>
            </div>
          </div>

          <div className="bg-slate-900 text-white p-6 rounded-3xl shadow-xl">
            <h4 className="font-black text-xs uppercase tracking-widest mb-4 opacity-75">AI Recommended Action Plan</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {insight.recommendations.map((r: string, i: number) => (
                <div key={i} className="flex flex-col gap-2 p-4 bg-white/10 rounded-2xl">
                  <span className="bg-white/20 w-8 h-8 flex items-center justify-center rounded-lg font-black text-xs">{i+1}</span>
                  <p className="text-xs font-medium leading-relaxed">{r}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
