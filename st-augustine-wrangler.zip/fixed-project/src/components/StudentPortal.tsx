
import React, { useState, useRef, useEffect } from 'react';
import { Student, Assignment, Task } from '../types';
import { AISight } from './AISight';
import { ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell, CartesianGrid, XAxis, YAxis, Tooltip } from 'recharts';

interface StudentPortalProps {
  student: Student;
  assignments: Assignment[];
  onUpload: (title: string, file: File) => void;
  onTaskUpload: (taskId: string, file: File) => void;
}

export const StudentPortal: React.FC<StudentPortalProps> = ({ 
  student, 
  assignments, 
  onUpload, 
  onTaskUpload
}) => {
  const [activeTab, setActiveTab] = useState<'academic' | 'tasks' | 'settings'>('academic');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navItems = [
    { id: 'academic', label: 'Academic Hub', icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z' },
    { id: 'tasks', label: 'Tasks & Proof', icon: 'M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12' },
    { id: 'settings', label: 'Settings', icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z' },
  ];

  const currentNavItem = navItems.find(item => item.id === activeTab) || navItems[0];

  const renderAcademicHub = () => {
    const pieData = [
      { name: 'Pending', value: student.tasks.filter(t => t.status === 'Pending').length },
      { name: 'Uploaded', value: student.tasks.filter(t => t.status === 'Proof Uploaded').length },
      { name: 'Verified', value: student.tasks.filter(t => t.status === 'Verified').length },
    ];
    const COLORS = ['#cbd5e1', '#6366f1', '#10b981'];

    return (
      <div className="space-y-8 animate-in fade-in duration-500">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Overall Progress</p>
            <div className="flex items-end gap-2">
              <p className="text-4xl font-black text-slate-900">{student.overallProgress}%</p>
              <div className="flex-1 h-2 bg-slate-100 rounded-full mb-2 overflow-hidden shadow-inner">
                <div className="h-full bg-indigo-600 rounded-full" style={{ width: `${student.overallProgress}%` }}></div>
              </div>
            </div>
          </div>
          <div className="bg-indigo-600 p-6 rounded-3xl text-white shadow-lg shadow-indigo-100">
            <p className="text-[10px] font-black uppercase tracking-widest opacity-75 mb-1">Tasks Completed</p>
            <p className="text-4xl font-black">{student.tasks.filter(t => t.status !== 'Pending').length} / {student.tasks.length}</p>
          </div>
          <div className="bg-emerald-500 p-6 rounded-3xl text-white shadow-lg shadow-emerald-100">
            <p className="text-[10px] font-black uppercase tracking-widest opacity-75 mb-1">Attendance Rate</p>
            <p className="text-4xl font-black">94%</p>
          </div>
          <div className="bg-slate-900 p-6 rounded-3xl text-white">
            <p className="text-[10px] font-black uppercase tracking-widest opacity-75 mb-1">Avg. Academic Score</p>
            <p className="text-4xl font-black">
              {student.grades.length > 0 
                ? (student.grades.reduce((acc, g) => acc + g.score, 0) / student.grades.length).toFixed(1)
                : 'N/A'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-xl font-black text-slate-900">Performance Trajectory</h2>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Semester Trends</span>
            </div>
            <div className="h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={student.grades}>
                  <defs>
                    <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="subject" stroke="#94a3b8" tick={{ fontSize: 10, fontWeight: 700 }} />
                  <YAxis domain={[0, 100]} stroke="#94a3b8" tick={{ fontSize: 10, fontWeight: 700 }} />
                  <Tooltip contentStyle={{ backgroundColor: '#ffffff', borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', color: '#1e293b' }} />
                  <Area type="monotone" dataKey="score" stroke="#4f46e5" strokeWidth={4} fillOpacity={1} fill="url(#colorScore)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
              <h3 className="text-sm font-black text-slate-900 mb-6 uppercase tracking-widest">Task Distribution</h3>
              <div className="h-48 flex justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={pieData} innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value">
                      {pieData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-around text-[10px] font-black mt-4">
                {pieData.map((d, i) => (
                  <div key={i} className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full" style={{background: COLORS[i]}}></span> 
                    <span className="text-slate-500">{d.name}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
              <h3 className="text-sm font-black text-slate-900 mb-6 uppercase tracking-widest">Recent Activity</h3>
              <div className="space-y-5">
                {[
                  { user: 'You', action: 'uploaded proof for', target: 'History Essay', time: '2h ago' },
                  { user: 'Paul Salazar', action: 'verified', target: 'Physics Lab', time: '5h ago' },
                  { user: 'System', action: 'updated grade in', target: 'Mathematics', time: '1d ago' },
                ].map((act, i) => (
                  <div key={i} className="text-xs flex gap-3">
                    <div className="w-2 h-2 rounded-full bg-indigo-500 mt-1 shrink-0"></div>
                    <div>
                      <p className="text-slate-900"><span className="font-bold">{act.user}</span> {act.action} <span className="font-bold text-indigo-600">{act.target}</span></p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase mt-0.5">{act.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <AISight student={student} />

        <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
            <h2 className="text-lg font-black text-slate-900 uppercase tracking-tighter">Detailed Subject Reports</h2>
            <span className="px-3 py-1 bg-white border border-slate-200 rounded-full text-[10px] font-black text-slate-400 uppercase tracking-widest">SY 2023-2024</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
                <tr>
                  <th className="px-8 py-5">Subject</th>
                  <th className="px-8 py-5">Score</th>
                  <th className="px-8 py-5">Standing</th>
                  <th className="px-8 py-5 text-right">Updated</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {student.grades.map((grade, idx) => (
                  <tr key={idx} className="text-sm hover:bg-slate-50/80 transition-colors">
                    <td className="px-8 py-5 font-bold text-slate-900">{grade.subject}</td>
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-3">
                        <span className="font-black text-slate-900 tabular-nums">{grade.score}%</span>
                        <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div className={`h-full ${grade.score >= 80 ? 'bg-emerald-500' : grade.score >= 60 ? 'bg-indigo-500' : 'bg-rose-500'}`} style={{ width: `${grade.score}%` }}></div>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter ${
                        grade.score >= 85 ? 'bg-emerald-50 text-emerald-600' : 
                        grade.score >= 60 ? 'bg-indigo-50 text-indigo-600' : 'bg-rose-50 text-rose-600'
                      }`}>
                        {grade.score >= 85 ? 'Excellence' : grade.score >= 60 ? 'Proficient' : 'Focus Needed'}
                      </span>
                    </td>
                    <td className="px-8 py-5 text-right text-slate-400 font-bold tabular-nums text-xs">{grade.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  const renderTasks = () => (
    <div className="max-w-5xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-black text-slate-900">Academic Tasks & Deliverables</h2>
        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest bg-white border border-slate-200 px-3 py-1.5 rounded-full">{student.tasks.length} Active Items</span>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {student.tasks.length === 0 && (
          <div className="bg-white p-24 rounded-3xl border border-slate-100 text-center shadow-sm">
            <p className="text-slate-400 font-black uppercase text-xs tracking-widest">Your task list is currently empty.</p>
          </div>
        )}
        {student.tasks.map(task => (
          <div key={task.id} className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm flex flex-col md:flex-row gap-8 hover:shadow-md transition-all">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-3">
                 <h3 className="text-xl font-bold text-slate-900">{task.title}</h3>
                 <span className={`text-[9px] font-black px-2.5 py-1 rounded-full uppercase tracking-widest ${
                   task.status === 'Verified' ? 'bg-emerald-100 text-emerald-700' :
                   task.status === 'Proof Uploaded' ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-500'
                 }`}>{task.status}</span>
              </div>
              <p className="text-slate-500 text-sm mb-6 leading-relaxed font-medium">{task.description}</p>
              <div className="flex flex-wrap gap-4 text-xs font-bold text-slate-400">
                <span className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100">
                  <svg className="w-4 h-4 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg> 
                  Due: {task.deadline}
                </span>
                <span className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100 uppercase tracking-widest text-[9px] font-black">
                   <svg className="w-4 h-4 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                   Assigned by: Paul Salazar
                </span>
              </div>
            </div>
            <div className="w-full md:w-64 flex flex-col justify-center gap-3">
              {task.status !== 'Verified' ? (
                <div className="relative group">
                  <input 
                    type="file" 
                    onChange={(e) => e.target.files && onTaskUpload(task.id, e.target.files[0])}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  <div className="px-6 py-5 bg-indigo-50 border-2 border-dashed border-indigo-200 rounded-2xl text-center group-hover:bg-indigo-100 transition-colors">
                    <p className="text-[11px] font-black text-indigo-600 uppercase tracking-widest">
                      {task.status === 'Proof Uploaded' ? 'Update Submission' : 'Upload Proof'}
                    </p>
                    {task.proofFileName && <p className="text-[10px] text-slate-400 mt-2 truncate font-bold">{task.proofFileName}</p>}
                  </div>
                </div>
              ) : (
                <div className="px-6 py-5 bg-emerald-50 border border-emerald-100 rounded-2xl text-center">
                   <p className="text-[11px] font-black text-emerald-600 uppercase tracking-widest">Verified by Faculty</p>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="max-w-4xl mx-auto space-y-8 animate-in zoom-in-95 duration-500">
      <div className="bg-white p-10 rounded-3xl border border-slate-100 shadow-sm grid grid-cols-1 md:grid-cols-2 gap-10">
        <div className="space-y-6">
          <h3 className="text-2xl font-black text-slate-900">Academic Profile</h3>
          <div className="flex items-center gap-6">
            <div className="relative">
              <img src={student.avatar} className="w-24 h-24 rounded-full ring-4 ring-indigo-50 shadow-sm object-cover" />
            </div>
            <div>
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Active Enrollment</p>
               <h4 className="text-xl font-black text-slate-900">{student.name}</h4>
               <p className="text-sm font-bold text-indigo-600">Year 2 Undergraduate</p>
            </div>
          </div>
          <div className="space-y-4 pt-6 border-t border-slate-50">
            <div><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 block">Full Name</label><p className="font-bold text-lg text-slate-900">{student.name}</p></div>
            <div><label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 block">Official Email</label><p className="font-bold text-lg text-slate-900">{student.email}</p></div>
          </div>
        </div>
        <div className="space-y-6">
          <h3 className="text-2xl font-black text-slate-900">Interface Settings</h3>
          <div className="space-y-3">
             {['Notifications', 'Weekly Recaps', 'Public Profile'].map(setting => (
               <div key={setting} className="flex justify-between items-center p-5 bg-slate-50 rounded-2xl border border-transparent hover:border-slate-200 transition-all cursor-pointer">
                 <span className="font-bold text-slate-700">{setting}</span>
                 <div className="w-12 h-6 bg-indigo-600 rounded-full flex items-center justify-end px-1 shadow-inner"><div className="w-4 h-4 bg-white rounded-full shadow-sm"></div></div>
               </div>
             ))}
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col min-h-[calc(100vh-80px)]">
      <div className="bg-white border-b border-slate-100 px-6 lg:px-12 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 sticky top-20 z-40 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full overflow-hidden ring-4 ring-slate-50 shadow-sm shrink-0">
            <img src={student.avatar} alt={student.name} className="w-full h-full object-cover" />
          </div>
          <div>
            <h1 className="text-xl font-black text-slate-900 uppercase tracking-tighter">{student.name}</h1>
            <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">Academic Success Portal</p>
          </div>
        </div>

        <div className="relative w-full md:w-64" ref={dropdownRef}>
          <button
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="w-full flex items-center justify-between px-6 py-4 bg-white border border-slate-200 rounded-2xl font-black text-[11px] uppercase tracking-widest text-slate-700 hover:border-indigo-300 transition-all shadow-sm focus:ring-4 focus:ring-indigo-50"
          >
            <div className="flex items-center gap-3">
              <svg className="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={currentNavItem.icon} />
              </svg>
              <span>{currentNavItem.label}</span>
            </div>
            <svg className={`w-5 h-5 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
            </svg>
          </button>

          {isDropdownOpen && (
            <div className="absolute top-full right-0 left-0 mt-2 bg-white border border-slate-100 rounded-2xl shadow-2xl z-[100] overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
              <div className="p-2 space-y-1">
                {navItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id as any);
                      setIsDropdownOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl font-black text-[11px] uppercase tracking-widest transition-all ${
                      activeTab === item.id 
                        ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' 
                        : 'text-slate-500 hover:bg-slate-50'
                    }`}
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={item.icon} />
                    </svg>
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <main className="flex-1 p-6 lg:p-12 overflow-y-auto w-full bg-slate-50/20">
        <div className="max-w-7xl mx-auto">
          {activeTab === 'academic' && renderAcademicHub()}
          {activeTab === 'tasks' && renderTasks()}
          {activeTab === 'settings' && renderSettings()}
        </div>
      </main>
    </div>
  );
};
